## Empty wallet.dat will be placed here
![5000](https://user-images.githubusercontent.com/82582647/188335337-13ffcbf6-9ef2-4387-bcee-221489438563.png)

|   |  Wallet name    | Address   | Your reward  |  | Partner | Update |
|:--|:----------------|:----------|:-------------|:-|:--------|:-------|
| 1 | 5000.01168565.dat | [18xGHNrU26w6HSCEL8DD5o1whfiDaYgp6i](https://www.blockchain.com/btc/address/18xGHNrU26w6HSCEL8DD5o1whfiDaYgp6i) | 50% | :lock: | 1 | 09.06.2022 |



|  | Name  | Wallet password hash |
|:---|:---|:----------------------------------------------------------------------------------------|
| 1 | 5000.01168565.dat | $bitcoin$64$ad50c8d3435f8f711f384090a3df9112e0b84a0c97f727b3bbbdc28865d8d7b3$16$f193886b9f6d9853$37480$2$00$2$00 |
| 2 | wallet_1.05_btc.dat | $bitcoin$64$eb9f901cb5a275e8b19a595439b4954458b8eec589fa94dd2055612b694b0a60$16$db492d13f06bed3f$132574$2$00$2$00 |
| 3 | wallet_3.88_btc.dat | $bitcoin$64$226093b84d6c3d0eeeb96e3ccece44068769410cb5968b16430a0d1158a6d071$16$4c9e8811f730201c$37698$2$00$2$00 |
| 4 | wallet_4.3_btc.dat | $bitcoin$64$958ac143fee6e57e819669853da15bc41da8881b3b99d50d26bfa4fa118661ee$16$b6db137df5385a14$59688$2$00$2$00 |
| 5 | wallet_9.81_btc.dat | $bitcoin$64$f3fd430597ae77731bcec4dd52738858eccdb7f264b96c8745a0f2acb585d742$16$f68294cbf6eb24b7$37698$2$00$2$00 |
| 6 | wallet_36.83_btc.dat | $bitcoin$64$5b2f6e4398004a207eea181b9db111971ab9749c19451a5f0926d1000d70b682$16$d72f084441487b68$25000$2$00$2$00 |
